package com.mobile.pl;

import java.util.List;
import java.util.Scanner;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;
import com.mobile.service.MobileService;
import com.mobile.service.MobileServiceImpl;

public class MPSApp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ch;

		do {
			MobileService service = new MobileServiceImpl();
			PurchaseDetail pbean = new PurchaseDetail();
			List<PurchaseDetail> list = null;
			List<MobileBean> list1 = null;
			System.out.println("WELCOME TO MOBILE PURCHASE SYSTEM");
			System.out.println("---------------------------------");
			System.out
					.println("1.Insert Mobile ID.\n2.View Records\n3.Delete Records\n4.Search Mobile");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Cutomer Name = ");
				String name = sc.next();
				System.out.println("Enter contact number = ");
				long phone = sc.nextLong();
				System.out.println("Enter Customer Email Id = ");
				String email = sc.next();
				System.out.println("Enter Mobile ID = ");
				int id = sc.nextInt();
				pbean.setMobileid(id);
				pbean.setCname(name);
				pbean.setPhoneno(phone);
				pbean.setMailid(email);

				try {
					if(service.validateEmployee(pbean)){
					int eid = service.addPurchaseDetails(pbean);
					System.out.println("Customer details Added Successfully\n"
							+ eid);
					}
				} catch (MobileException e) {
					  System.out.println(e);

				}
				break;

			case 2:

				try {
					list = service.viewAllRecords();
					for (PurchaseDetail bean : list) {
						System.out.println("Customer Details");
						System.out.println("------------------");
						System.out.println(bean.toString());
					}

				} catch (MobileException e) {

					System.out.println("Error : " + e.getMessage());
				}
				break;
			case 3:

				System.out.println("Enter MobileID: ");
				int mobileid = sc.nextInt();
				try {
					int mid = service.deleteEmployeeById(mobileid);
					System.out.println("Mobile ID deleted successfully\n "
							+ mid);
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 4:
				System.out
						.println("Enter the price range and get mobile details.\n");
				float price = sc.nextFloat();
				try {
					list1 = service.searchMobileByPrice(price);
					for (MobileBean mbean : list1) {
						System.out.println("Mobile details:");
						System.out.println("----------------");
						System.out.println(mbean.toString());
					}
				} catch (MobileException e) {
					System.out.println(e.getMessage());
				}
				break;
			default: {
				System.out.println("Invalid Choice");
			}
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			ch = sc.nextInt();
		} while (ch != 2);
		
		System.out.println("ThankYou! Welcome back Again.");
		

	}
}
