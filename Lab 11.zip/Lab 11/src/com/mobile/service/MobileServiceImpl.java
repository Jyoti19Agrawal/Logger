package com.mobile.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.dao.MobileDao;
import com.mobile.dao.MobileDaoImpl;
import com.mobile.exception.MobileException;

public class MobileServiceImpl implements MobileService{
	private MobileDao mobileDao=new MobileDaoImpl();
	@Override
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException {
		int id = mobileDao.addPurchaseDetails(bean);
		return id;
	}
	@Override
	public List<PurchaseDetail> viewAllRecords() throws MobileException {
		List<PurchaseDetail> custList=mobileDao.viewAllRecords();
		return custList;
	}
	@Override
	public int deleteEmployeeById(int mobileid) throws MobileException {
		 int id=mobileDao.deleteEmployeeById(mobileid);
		return id;
	}
	 
	@Override
	public List<MobileBean> searchMobileByPrice(float price) throws MobileException {
		 List<MobileBean> mobList= mobileDao.searchMobileByPrice(price);
		return mobList;
	} 
	
	
	 
	@Override
	public boolean validateEmployee(PurchaseDetail bean) throws MobileException {
		boolean validate=true;
		List<String> validationErrors = new ArrayList<String>();

	 
		if(!(isValidName(bean.getCname())))
		{
			validationErrors.add("\n Customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		 
		if(!(isValidMail(bean.getMailid()))){
			validationErrors.add("\n Email Id Should Be Valid mail Id \n");
		}
		 
		if(!(isValidPhoneNumber(bean.getPhoneno())))
		{
			validationErrors.add("\n Phone Number Should be in 10 digit only \n");
		}
		 
		if(!(isValidMobileid(bean.getMobileid()))){
			validationErrors.add("\n Mobile id should contain only 4 digits and it should be one of the mobile id available in stores.\n" );
		}
		
		 if(!validationErrors.isEmpty())
		 {	
			 validate=false;
			throw new MobileException(validationErrors +"");
		 }
		 else
		 {
			 validate=true;
		 }
		 return validate;
	}
	 
	

	public boolean isValidMobileid(int mobileid) {
		Pattern idPattern = Pattern.compile("[0-9]{4}");
		Matcher idMatcher = idPattern.matcher(String.valueOf(mobileid));
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
	public boolean isValidPhoneNumber(long phoneno) {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(String.valueOf(phoneno));
		return phoneMatcher.matches();
		
	}
	public boolean isValidMail(String mailid) {
		Pattern emailPattern=Pattern.compile("^[a-z0-9.%_+-]+@[a-z]+\\.[a-z]{2,6}$");
		Matcher email=emailPattern.matcher(mailid);
		return email.matches();
		 
	}
	public boolean isValidName(String CustomerName){
		Pattern namePattern=Pattern.compile("^[A-Z][a-z]{2,19}$");
		Matcher nameMatcher=namePattern.matcher(CustomerName);
		return nameMatcher.matches();
	}
	
	 
	 
	 

}
