package com.mobile.service;

import java.util.List;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;

public interface MobileService {
	
	public int addPurchaseDetails(PurchaseDetail pbean) throws MobileException;
	public List<PurchaseDetail>viewAllRecords() throws MobileException;
	public int deleteEmployeeById(int mobileid) throws MobileException;
	public List<MobileBean> searchMobileByPrice(float price) throws MobileException;
	public boolean validateEmployee(PurchaseDetail bean) throws MobileException;

}
