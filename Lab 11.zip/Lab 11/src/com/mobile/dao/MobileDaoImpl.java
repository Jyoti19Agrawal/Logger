package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class MobileDaoImpl implements MobileDao {
	Logger logger=Logger.getLogger(MobileDaoImpl.class);
	
	public MobileDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	Connection con = null;
	Statement stmt = null;
	ResultSet rst = null;
	MobileBean mbean = new MobileBean();

	public int getpurchaseId() {
		int id = 0;
		logger.info("Generating Purchase Id");
		String myquery = "select purchaseid_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			rst = stmt.executeQuery(myquery);
			rst.next();
			id = rst.getInt(1);
			logger.info("Purchase Id generated");
		} catch (Exception e) {
			logger.error("ID cannot be generated");
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException {
		logger.info("Establishing connection");
		Connection con = null;
		int id = 0;

		try {
			logger.warn("Databse connected");
			con = DBConnection.getConnection();
			String cd = "select mobileid from mobiles where mobileid=?";
			PreparedStatement ps = con.prepareStatement(cd);
			ps.setInt(1, bean.getMobileid());
			rst = ps.executeQuery();
			if (rst.next()) {
				String cmd = "insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values (?,?,?,?,sysdate,?)";
				con = DBConnection.getConnection();
				id = getpurchaseId();
				PreparedStatement pstmt = con.prepareStatement(cmd);
				pstmt.setInt(1, id);
				pstmt.setString(2, bean.getCname());
				pstmt.setLong(3, bean.getPhoneno());
				pstmt.setString(4, bean.getMailid());
				pstmt.setLong(5, bean.getMobileid());
				int n = pstmt.executeUpdate();
				logger.info("Data inserted");
				
				logger.debug("updating the mobile table");
				String sql = "update mobiles set quantity=quantity-1 where mobileid=?";
				PreparedStatement conn = con.prepareStatement(sql);
				conn.setInt(1, bean.getMobileid());
				int n1 = conn.executeUpdate();
				logger.info("Table Updated");
			} else {
				logger.error("Mobile Id not found");
				throw new MobileException("Id does not exist!");
			}

		} catch (SQLException e) {
			logger.error("Error while Inserting");
			e.printStackTrace();
			throw new MobileException("Unable to insert");
		}
		return id;

	}

	@Override
	public List<PurchaseDetail> viewAllRecords() throws MobileException {
		logger.debug("View all Records command started");

		List<PurchaseDetail> custList = new ArrayList<PurchaseDetail>();
		try {
			logger.warn("Databse Connected");
			con = DBConnection.getConnection();
			String cmd = "select purchaseid,cname,mailid,phoneno,purchasedate,mobileid from purchasedetails";
			PreparedStatement ps = null;
			ps = con.prepareStatement(cmd);
			rst = ps.executeQuery();

			while (rst.next()) {
				PurchaseDetail bean = new PurchaseDetail();
				bean.setPurchaseid(rst.getInt(1));
				bean.setCname(rst.getString(2));
				bean.setPhoneno(rst.getLong(3));
				bean.setMailid(rst.getString(4));
				bean.setPurchasedate(rst.getDate(5));
				bean.setMobileid(rst.getInt(6));
				custList.add(bean);
				logger.info("Record Found");
			}
		} catch (SQLException e) {
			logger.error("Data connection lost");
			System.out.println("CONNECTION LOST");

		}
		return custList;

	}

	@Override
	public int deleteEmployeeById(int mobileid) throws MobileException {
		logger.debug("Deleting records by Id");
		PreparedStatement pstmt = null;
		try {
			logger.warn("Databse Connected");
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "delete from purchasedetails where mobileid= ?";
			pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, mobileid);
			rst = pstmt.executeQuery();
			int n = pstmt.executeUpdate();

			String delete = "delete from mobiles where mobileid=?";
			PreparedStatement pstmt1 = con.prepareStatement(delete);
			pstmt1.setInt(1, mobileid);
			rst = pstmt1.executeQuery();
			logger.info("Records deleted successfully");
		} catch (SQLException e) {
			logger.error("Id does not exist");
			throw new MobileException("Id Does Not Exist");

		}

		return mobileid;

	}
	@Override
	public List<MobileBean> searchMobileByPrice(float price) throws MobileException {
		logger.debug("Search By price Range");
		List<MobileBean> mobList = new ArrayList<MobileBean>();
	 
		try {
			logger.warn("Databse Connected");
			con=DBConnection.getConnection();
			stmt = con.createStatement();
			 String search = "select mobileId,name,price,quantity from mobiles where price=?";
			 PreparedStatement pSearch=con.prepareStatement(search);
			 //pSearch.setFloat(1,mbean.getPrice());
			 pSearch.setFloat(1,price);
			 rst=pSearch.executeQuery();
			  
			 while(rst.next())
			 {
				 mbean.setMobileId(rst.getInt(1));
				 mbean.setName(rst.getString(2));
				 mbean.setPrice(rst.getFloat(3));
				 mbean.setQuantity(rst.getInt(4));
				 mobList.add(mbean);
				 logger.info("Details of Mobile using price range");
				 
			 }
		} catch (SQLException e) {
			logger.error("No Record Found");
			 e.printStackTrace();
			 throw new MobileException("No record found");
		}

		return mobList;
	}
}
