package com.mobile.dao;

import java.util.List;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;

public interface MobileDao {
	
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException;
	public List<PurchaseDetail> viewAllRecords() throws MobileException;
	public int deleteEmployeeById(int mobileid) throws MobileException;
	 public List<MobileBean> searchMobileByPrice(float price) throws MobileException;

}
