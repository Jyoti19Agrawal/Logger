package com.mobile.bean;


public class MobileBean {
	
	private int mobileId;
	private String name;
	private float price;
	private int quantity;

	public MobileBean() {

	}

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int i) {
		this.quantity = i;
	}

	@Override
	public String toString() {
		return 	"MobileId       = " + mobileId +
				"\nMobile Name = " + name+ 
				"\nMobile Price= " + price + 
				"\nQuantity    = " + quantity;
	}
	
	 
	
	
}
