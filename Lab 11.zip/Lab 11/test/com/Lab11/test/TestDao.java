package com.Lab11.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import javax.jws.soap.InitParam;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.dao.MobileDaoImpl;
import com.mobile.exception.MobileException;

public class TestDao {
	static MobileDaoImpl mobileDao;
	static MobileBean mobBean;
	static PurchaseDetail custBean;
	@BeforeClass
	public static void beforeClass()
	{
		mobileDao=new MobileDaoImpl();
		//mobBean=new MobileBean(1004,"Moto G",18000.0f,40);
		custBean=new PurchaseDetail(100,"Payal","abc@gmail.com",9874563210L,new Date("11/29/2017"),1003);
	}
	 
	@Test
	public void testAddCustomerDetails() throws MobileException{

		assertNotNull(mobileDao.addPurchaseDetails(custBean));

	}

	/************************************
	 * Test case for addCustomerDetails()
	 * 
	 ************************************/

	 @Ignore 
	@Test
	public void testAddCustomerDetails1() throws MobileException {
		// increment the number next time you test for positive test case
		assertEquals(1002, mobileDao.addPurchaseDetails(custBean));
	}
	
	 
	@Test
	public void testAddCustomerDetails2() throws MobileException {

		custBean.setCname("Nehal"); 
		custBean.setMobileid(1003);
		custBean.setMailid("abc@gmail.com");
		custBean.setPhoneno(9874563210L);
		assertTrue("Data Inserted successfully",
				 (mobileDao.addPurchaseDetails(custBean)) > 0);

	}
	
	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAllRecords() throws MobileException {
		assertNotNull(mobileDao.viewAllRecords());
	}

	/********************************************
	 * Test case for deleteRecordById()
	 ************************************************/
	@Test
	public void testdeleteRecords() throws MobileException {
		assertNotNull(mobileDao.deleteEmployeeById(1002));
	}

	/********************************************
	 * Test case for searchRecordByPrice()
	 ************************************************/
	
	@Test
	public void testMobileByPrice() throws MobileException {
		assertNotNull(mobileDao.searchMobileByPrice(15000));
	}

}
