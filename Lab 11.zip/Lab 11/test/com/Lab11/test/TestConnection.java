package com.Lab11.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class TestConnection {
	@Test
	public void testConnection() throws MobileException
	{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
		System.out.println("Connected Successfully");
		
	}
	
	@Test(expected= MobileException.class)
	public void testConnectionFail() throws MobileException
	{
		Connection con=DBConnection.getConnection();
		System.out.println("Connection Fail");
	}
}



